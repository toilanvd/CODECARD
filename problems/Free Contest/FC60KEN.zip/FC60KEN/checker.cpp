#include <bits/stdc++.h>
#define ld long double
#define ll long long

using namespace std;

typedef pair<int,int> ii;

int n, m, sta, fin, budget;
int a[105];
map<ii,bool> edge;

int main (int argc, char *argv[])
{
	ofstream logfile(argv[3]);
	ifstream output(argv[2]);
	ifstream input(argv[4]);

	input >> n >> m >> sta >> fin >> budget;
	for(int i=1;i<=n;i++) input >> a[i];
	while(m--){
        int x, y; input >> x >> y;
        edge[ii(x,y)] = true; edge[ii(y,x)] = true;
	}

	int u, cnt = 0, last;
	while(output >> u){
        cnt++;
        if(cnt == 1 && u != sta){
            logfile << "wrong answer";
            return 0;
        }
        if(cnt >= 2 && edge.find(ii(u,last))==edge.end()){
            logfile << "wrong answer";
            return 0;
        }
        budget -= a[u]; last = u;
	}
	if(last != fin) logfile << "wrong answer";
	else if(budget != 0) logfile << "wrong answer";
	else logfile << "identical";

	return 0;
}
