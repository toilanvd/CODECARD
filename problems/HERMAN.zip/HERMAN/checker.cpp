#include <cstdio>
#include <string>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstddef>

using namespace std;

double abso(double x){
    if(x<0.0) return -x;
    return x;
}

int main(int argc, char* argv[]){
    FILE* ans = fopen(argv[1], "r");
    FILE* out = fopen(argv[2], "r");
    FILE* result_file = fopen(argv[3], "w");

    double x, y;
    while(true){
        int read_ans = (int)fscanf(ans, "%lf", &x);
        int read_out = (int)fscanf(out, "%lf", &y);
        if(read_ans == -1 && read_out == -1) break;
        if(read_ans == -1 || read_out == -1 || abso(x-y)>0.0001){
            fprintf(result_file, "differ\n");
            fclose(result_file); return 0;
        }
    }
    fprintf(result_file, "identical\n");
    fclose(result_file);

    return 0;
}
